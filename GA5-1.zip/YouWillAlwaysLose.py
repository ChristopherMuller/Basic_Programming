import random#Enables you to generate random numbers

credituser=100#Starting credits

while True:#Repitition needed
  print("WELCOME TO YOU WILL ALWAYS LOSE")
  print("")
  print("WIN BIG OR GO HOME WITH NOTHING")
  print("")
  print("GET 3 OF THE SAME NUMBER TO WIN DOUBBLE WHAT YOU PLAYED")
  print("")
  print("YOU CURRENTLY HAVE "+str(credituser)+" Credits,HOW MUCH WOULD YOU LIKE TO PLAY")
  print("")#Needed information for the user

    
  creditneeded=input()#What the user wants to bet

  double=int(creditneeded)*2#Prize when user wins

  if credituser<int(creditneeded) :#If user bets more than he has
      print("YOU SEEM TO BE TOO BROKE TO DO THAT, GOODBEY")
      print("YOU HAVE CASHED OUT "+str(credituser)+" CREDITS")
      print("COME LOSE AGAIN SOON!!!!!!!! HAHAHAHAHA")#Needed text will be displayed
      break#Program will stop

  else:
    print("YOUR NUMBERS ARE.........")#Needed information for the user
    print("")
    credituser=credituser-int(creditneeded)#Current ammount of coins left

    rand1=random.randrange(1,11)
    rand2=random.randrange(1,11)
    rand3=random.randrange(1,11)#Generates 3 random integers

    print(str(rand1)+"   "+str(rand2)+"   "+str(rand3))#Displayes the 3 numbers to user

  if (rand1==rand2) and (rand1==rand3) :#If all 3 numbers are the sme user wins
      print("YOU HAVE WON "+str(double)+" CREDITS!!!!!!!")#Needed information for the user
      
  else:
      print("YOU HAVE LOST THAT ONE!!!!!!!!HAHAHAHA")#Needed information for the user
      print("")

  awnser=input("WANT TO PLAY AGAIN??? y/n ",)#Asks user if he wants to keep playing or cashe out

  if awnser=="n" :
      print("YOU HAVE CASHED OUT 80 CREDITS")
      print("COME LOSE AGAIN SOON!!!!!!HAHAHAHAHA")#Needed information for the user
      break
  
      
      
      
  

  

  
