import random

credituser=100



while True:
  print("WELCOME TO YOU WILL ALWAYS LOSE")
  print("")
  print("WIN BIG OR GO HOME WITH NOTHING")
  print("")
  print("GET 3 OF THE SAME NUMBER TO WIN DOUBBLE WHAT YOU PLAYED")
  print("")
  print("YOU CURRENTLY HAVE "+str(credituser)+" Credits,HOW MUCH WOULD YOU LIKE TO PLAY")
  print("")

    
  creditneeded=input()

  double=int(creditneeded)*2

  if credituser<int(creditneeded) :
      print("YOU SEEM TO BE TOO BROKE TO DO THAT, GOODBEY")
      print("YOU HAVE CASHED OUT "+str(credituser)+" CREDITS")
      print("COME LOSE AGAIN SOON!!!!!!!! HAHAHAHAHA")
      break

  else:
    print("YOUR NUMBERS ARE.........")
    print("")
    credituser=credituser-int(creditneeded)

    rand1=random.randrange(1,11)
    rand2=random.randrange(1,11)
    rand3=random.randrange(1,11)

    print(str(rand1)+"   "+str(rand2)+"   "+str(rand3))

  if (rand1==rand2) and (rand1==rand3) :
      print("YOU HAVE WON "+str(double)+" CREDITS!!!!!!!")
      
  else:
      print("YOU HAVE LOST THAT ONE!!!!!!!!HAHAHAHA")
      print("")

  awnser=input("WANT TO PLAY AGAIN??? y/n ",)

  if awnser=="n" :
      print("YOU HAVE CASHED OUT 80 CREDITS")
      print("COME LOSE AGAIN SOON!!!!!!HAHAHAHAHA")
      break
  
      
      
      
  

  

  
