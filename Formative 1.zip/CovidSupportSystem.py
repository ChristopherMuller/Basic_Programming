SA=270403
USA=1700000
China=82995
x=1

while x==1 :
 print("Welcome to the COVID 19 support service. Please select an option below:")
 print("1.Statistics")
 print("2.Prevention")
 print("3.Syptoms")
 print("4.Treatment")
 print("5.Report case")
 print("6.Exit")#Gives options to the user

 choice=input("Enter choice(1/2/3/4/5/6): ",)#To get the choice the user made

 print("")#Inserts a space in text
 if choice=="1" :
    print("Currently in SA there are "+str(SA)+" confirmed cases")#Indicates when confirmed cases are increased
    print("Currently in USA there are "+str(USA)+" confirmed cases")
    print("Currently in SA there are "+str(China)+" confirmed cases")
    print("")#Inserts a space in text
    yesno1=input("Would you like to see Confirmed cases for a random country? y/n: ",)#To get a yes or no awnser
    print("")#Inserts a space in text
    if yesno1=="y":#If yes,needs a number to se a random countries' confirmed cases
        randomcountry=input("To select a random country, type a number from 0 to 9: ",)

        if randomcountry=="1" :
          print("India has 586374  confirmed cases")
        elif randomcountry=="2" :
          print("Brazil has 4957885 confirmed cases")
        elif randomcountry=="3" :
          print("Russia has  361295 confirmed cases")
        elif randomcountry=="4" :
          print("Mexico has 282791  confirmed cases")
        elif randomcountry=="5" :
          print("UK has 275597 confirmed cases")
        elif randomcountry=="6" :
          print("Argentina has 290479  confirmed cases")
        elif randomcountry=="7" :
          print("Australia has 7155 confirmed cases")
        elif randomcountry=="8" :
          print("Iran has 248263 confirmed cases")
        elif randomcountry=="9" :
          print("Finland has 48115 confirmed cases")#Gives the random countries' confirmed cases
    print("")
    print("")
    print("")#Inserts a space in text
    

 elif choice=="2" :
    print("To prevent the spread of Covid-19:")
    print("Clean your hands often. Use soap and water, or an alcohol-based hand rub.")
    print("Maintain a safe distance from anyone who is coughing or sneezing.")
    print("Don't touch your eyes, nose or mouth")
    print("Cover your nose and mouth with your bent elbow or tissue when cough or sneeze.")
    print("Stay home if you feel unwell")
    print("If you have a fever, cough or difficulty breathing, seek medical attention. Call in advance.")
    print("Follow the directions of your local health authority.")#Gives user needed information
    print("")
    print("")
    print("")#Inserts a space in text

 elif choice=="3" :
    print("Most common syptoms:")
    print("fever")
    print("dry cough")
    print("tiredness")
    print("")#Inserts a space in text
    print("Less common syptoms:")
    print("aches and pains")
    print("sore throat")
    print("diarrhea")
    print("conjuctivitus")
    print("headache")
    print("loss of taste and smell")
    print("a rash on skin, or discoloration of fingers or toes")
    print("")#Inserts a space in text
    print("Serious symptoms:")
    print("diffuculty breathing")
    print("chest pain or pressure")
    print("loss of speech or movement")#Gives user needed information
    print("")
    print("")
    print("")#Inserts a space in text

 elif choice=="4" :
    print("If you feel sick you should rest, drink plenty of fluid, and eat nutrisious food. Stay in a seperate room")
    print("from other family members, and use a dedicated bathroom if possible. Clean and disinfect")
    print("frequently touched surfaces.")#Gives user needed information
    print("")
    print("")
    print("")#Inserts a space in text

 elif choice=="5" :
    yesnosymptoms=input("Do you have any of the sypmtoms? y/n: ",)#Gets a yes/no awnser from user

    if yesnosymptoms=="y" :
      yesnotemprature=input("Is your temprature above 38.5 degrees? y/n: ",)#Gets a yes/no awnser from user

      if yesnotemprature=="y" :
        print("In wich country are you select an option below")
        print("1.SA")
        print("2.USA")
        print("3.China")
        country=input("Enter option(1/2/3): ")#Gets the country of the user

        if country=="1":
            SA+=1
        if country=="2":
            USA+=1
        if country=="3":
            China+=1#Increases the number of confirmed cases by one
        print("You have Covid 19 please seek treatment")#Gives user needed information
        print("")
        print("")
        print("")#Inserts a space in text

 elif choice=="6" :#Ends program
     x+=1

    
    
    
