#Christopher Muller 10395

import turtle #To use turtle
import time #To work with time
import random #To use random to get diffrent movements

screen= turtle.Screen()#Initializes the turtle's screen 
screen.title("Game Timer")#Gives the screen a title
screen.bgcolor("black")#Cives the screen a color

frikkie= turtle.Turtle()#Initializes the turtle
frikkie.speed(5)#Speed of turtle
frikkie.color("red")#Colour of turtle
frikkie.shape("circle")#Shape of turtle
frikkie.penup()#So that the turtle doesn't draw a line behinf it

paused=False#Paused variable used to indicate if it's paused or not

def pause() :#Function used to pause and unpause
   global paused
   if paused==True:
      paused=False
   else:
      paused=True

screen.listen()#So that the screen would recognize user input
screen.onkeypress(pause,"p")#When p is pressed the pause function will be called

time_limit =10#The amount of time the program should be running
start_time= time.time()#When the time starts

while True:
    if paused==False:#When it's not paused the the program will run
        random1=random.randrange(2,6)#Moves randomly accross screen
        if random1==2 :
         frikkie.fd(15)
        if random1==3 :
         frikkie.bk(15)
        if random1==4 :
         frikkie.lt(15)
        if random1==5 :
         frikkie.rt(15)
         
        elapsed_time=time.time()-start_time#Amount of time left
        print(time_limit - int(elapsed_time))#Gives user needed information
        

        if elapsed_time > time_limit :
            print("Frikkie is tired now")
            print("Game Over")#Gives user needed information
            exit()#Asks if program should be killed

    else:#When game is paused
      start_time= time.time()-elapsed_time#Shows the time left
      screen.update()#Updates screen 

              
         
        
