#Christopher Muller 10395

arrmonths=["January","February","March","April","May","June","July","August","September","October","November","December"]
#Created list that hold all 12 months of year as string
while True:
    try:
       month=input("Insert number that represents the 12 months of the year: ",)#User input needed

       print(arrmonths[int(month)-1])#If number is between 1-12 ,the month representing the number will appear
       print("")
       print("")
       print("")#Creates space between lines
    except IndexError:#If the number is not between 1-12, needed information will be given to user, error diverted

        month=input("Please enter a number between 1 and 12: ")#User input needed
        print(arrmonths[int(month)-1])#If number is between 1-12 ,the month representing the number will appear
        print("")
        print("")
        print("")#Creates space between lines

    except ValueError:#If text is entered, needed information will be given to user, error diverted
        print("Please enter numbers only ")
        print("")
        print("")
        print("")#Creates space between lines
    
         
    



    
    
    
    




    
    
    
    



    
    
    
    
