#Christopher Muller 10395

import random#Imported so that I can generate random integers
arrint=[]#Creates list
plus=0#Declares integer
length=""#Declares string

while True:#Repeates if user wants to retry
  length=input("How many integers should list contain? ",)#Gets needed input from user

  for x in range(0,int(length)):#Number of repitions for number of intgers needed
      arrint.append(random.randrange(1,101))#Inserts a random integer into the list

  def sumList(arrint,length):#Creates function
      print(arrint)#Prints list
      global plus#plus can be used inside and outside function
      for x in range (0,int(length)):
          plus=plus+arrint[x]#Calculates the sum of the integers
      print("The total is: "+str(plus))#Gives output to user in the correct format
      print("")#Creates a space between lines
    
  sumList(arrint,length)#Calls function

  awnser=input("Would you like to try again? y/n ",)#Asks user if he wants to retry

  if awnser=="n":#If user doesn't want to retry program stops
      break

  print("")
  print("")
  print("")#Creates a space between lines


  
        
    
    
