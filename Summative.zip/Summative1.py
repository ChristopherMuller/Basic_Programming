#Christopher Muller 10395

while True :
  sentence=input("Enter a sentence of at least five words: ",)#Gets the sentence the user wants to use
  length=len(sentence)#Gets the amount of characters in the sentence
  arrorder=[]#Created a list
  arrcharachter=[]#Created a list
  word1=""#Used to create a word
  word2=""#Used to create a word
  reverse1=""#Used to display output in the correct format
  reverse2=""#Used to display output in the correct format

  counter=sentence.count(' ')+1#Counts the number of words in the sentece if it's correct

    
  if counter<5 :
      print("Should atleat have five words!")#Displays message if there aren't atleast five words
      break#Stops program
  else:
     for x in range(0,length):#Used to move from character to character in sentence
        if not sentence[x]==" " :#If character is not a space then it adds the character to the word
            word1=sentence[x]+word1
            word2=word2+sentence[x]
        else:
            arrorder.insert(0,word1)#When it's a space word gets inserted into list
            arrcharachter.insert(0,word2)#When it's a space word gets inserted into list
            word1=""#When it's a space word gets cleared
            word2=""#When it's a space word gets cleared
          
  arrorder.insert(0,word1)#Word gets inserted into list
  arrcharachter.insert(0,word2)#Word gets inserted into list

  for x in range (0,counter):#The lists contents gets inserted into a string
    reverse1=reverse1+" "+arrorder[x]
    reverse2=reverse2+" "+arrcharachter[x]


  print("Reverse order: "+reverse2)#The sting gets printed into the correct format
  print("Reverse order and letters: "+reverse1)#The sting gets printed into the correct format
  print("")#Creates a space between lines


  awnser=input("Want to try again? y/n: ",)#Asks user if he wants to try again

  print("")
  print("")
  print("")#Creates a space between lines

  if awnser=="n" :
      break#Stops program

  


     

    
    
