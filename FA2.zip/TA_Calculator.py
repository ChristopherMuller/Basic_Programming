#Christopher Muller 10395

counter=1
x=1

while x==1 :
 counter=counter+1
 base=input("Base of triangle ",)
 height=input("Height of triangle ",)


 def area_of_triangle(base,height):
     area=0.5*int(base)*int(height)
     print("The area of triangle equals to "+str(area))
    

 if counter<=3:
    if base > height :
        print("Height should be larger than base",)
        print("")
    

    else :
        area_of_triangle(base,height)
        break

 else:
     print("")
     print("You have exausted your 3 attempts please try again later",)
     break



