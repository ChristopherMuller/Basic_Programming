#Christopher Muller 10395

z=0 #Declares variable

sum1=0  #Declares variable

while z==0 :#Used so that program will automatically repeat if user wants to try again

 n=input("Enter a number to calculate the sum ",)#Gets n as input


 for x in range(1,int(n)+1):#Calculates the amount of itterations the sum wil have to complete
     sum1=sum1+x#Counts up total

 print("Sum of the first "+n+" natural numbers using formula is: "+str(sum1))#Gives needed information
    
 average=sum1/int(n)#Calculates the average of the sum


 print("Average of the first "+n+"natural numbers using formula is: "+str(average))#Gives needed information

 print("")#Creates space between text

 awnser=input("Want to enter a new number? y/n ",)#Gets needed information from user
 
 print("")
 print("")
 print("")#Creates space between text

 if awnser=="n" :#Stops repeating if user doesn't want to continue 
     z+=1

 

 
