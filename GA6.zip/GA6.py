import json



try:
 import requests

except ModuleNotFoundError as e:
    print(e)
    

finally:
    print("Welcome to AA Calculator")
    print("Please select one of the following options:")
    print("1.Have a look at the previos entry.")
    print("2.Make a new entry.")
    print("3.Close the program.")

    options= input()

    if options=="1":
      with open("Log.json") as json_file:
         data = json.load(jon_file)

    elif options=="2":
          ptint("How many meters have you travled")
          Traveled= int(input()/1000)

          option2=input()

          AA_Calc="https://raw.githubuserconnect.com/tyrone0501/AA-Petrol-Price/main/Cars.json"
          response=requests.get(AA_Calc)
          response_json=response.json()

          if option2=="1":
             siteresponse=response_json("Hatchback")
             TotalCost=Travled*sitresponse
          elif option2=="2":
             siteresponse=response_json("SUV")
             TotalCost=Travled*sitresponse
          elif option3== "3":
             siteresponse=response_json("Sportscar")
             TotalCost=Travled*sitresponse
          else:
             print("")
             print("That is not a valid option")
             print("")
        
          print("")
          print("Please type in your descryption of where you trvaled and why")
          print("")
          Descryption=input()

          mydetails = {"Cost" : TotalCost,"KM" : Traveled,"Descryption" :Descryption}

          with open("Log.json","w") as json_file:
             json.dump(mydetails,json_file)

    elif options =="3":
         print(3)

    else:
         print("")
         print("Please select a valid option")
         print("")
  
        
        
